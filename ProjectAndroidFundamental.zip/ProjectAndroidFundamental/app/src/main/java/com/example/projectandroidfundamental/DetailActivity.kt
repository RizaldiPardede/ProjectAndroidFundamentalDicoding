package com.example.projectandroidfundamental

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.projectandroidfundamental.Api.ApiConfig
import com.example.projectandroidfundamental.databinding.ActivityDetailBinding
import com.example.projectandroidfundamental.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import retrofit2.Call

class DetailActivity : AppCompatActivity() {
    private lateinit var bindingD: ActivityDetailBinding
    private lateinit var viewModel: MainViewModel
    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_followers,
            R.string.tab_following
        )
        var ParsingData = String()
        const val USERNAME = "extra_username"


    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindingD = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(bindingD.root)

        //variable username diambil dari data activity main yang digunakan sebagai getter data
        val username = intent.getStringExtra(USERNAME)

        if (username != null) {
            setUpView(username)
        }
        ParsingData =username.toString()
        tablayout()






    }

    //function tablayout digunakan untuk menampilkan tablayout followers dan following
    private fun tablayout(){
        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f
    }

    //function ini berfungsi untuk setup setiap view
    private fun setUpView(username:String){

        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        viewModel.getterDetail(username)

        viewModel.getDetail.observe(this, Observer{
            bindingD.usernamedetail.text=username
            bindingD.namedetail.text = it.name
            Glide.with(this@DetailActivity)
                .load(it.avatarUrl)
                .error(R.drawable.ic_launcher_background)
                .into(bindingD.avatarDetail)
            bindingD.followers.text = "${it.followers} Followers"
            bindingD.following.text = "${it.following} Following"

        })
        viewModel.getIsLoading.observe(this, this::showLoading)



//        showLoading(true)
//
//        bindingD.usernamedetail.text=username
//        val client = ApiConfig.getApiService().getDetailUser(username)
//        client.enqueue(object : retrofit2.Callback<ResponseDetail>{
//            override fun onResponse(
//                call: Call<ResponseDetail>,
//                response: retrofit2.Response<ResponseDetail>
//            ) {
//                showLoading(false)
//                if (response.isSuccessful){
//                    val responseBody = response.body()
//                    if (responseBody != null) {
//                        val datauser = responseBody
//                        bindingD.namedetail.text = datauser.name
//                        Glide.with(this@DetailActivity)
//                            .load(datauser.avatarUrl)
//                            .error(R.drawable.ic_launcher_background)
//                            .into(bindingD.avatarDetail)
//                        bindingD.followers.text = "${datauser.followers} Followers"
//                        bindingD.following.text = "${datauser.following} Following"
//
//                    }
//                }
//            }
//
//            override fun onFailure(call: Call<ResponseDetail>, t: Throwable) {
//                Toast.makeText(applicationContext,t.localizedMessage,Toast.LENGTH_SHORT)
//            }
//
//        })


    }

    //untuk menampilkan dan menghilangkan progress bar
    private fun showLoading(loading: Boolean) {
        if (loading) {
            bindingD.progressBarDetail.visibility = View.VISIBLE
        } else {
            bindingD.progressBarDetail.visibility = View.GONE
        }

    }
}